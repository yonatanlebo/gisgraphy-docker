#!/bin/bash
./start.sh;./logs.sh
